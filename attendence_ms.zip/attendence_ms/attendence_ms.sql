-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: attendence_ms
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actual_attendence`
--

DROP TABLE IF EXISTS `actual_attendence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actual_attendence` (
  `Attendence_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hours` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`Attendence_id`),
  KEY `fk_user_id_idx` (`user_id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `profile` (`profile_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actual_attendence`
--

LOCK TABLES `actual_attendence` WRITE;
/*!40000 ALTER TABLE `actual_attendence` DISABLE KEYS */;
INSERT INTO `actual_attendence` VALUES (32,'2017-06-26',9,1,0),(33,'2017-06-27',9,1,0),(34,'2017-06-28',9,1,0),(35,'2017-06-29',9,1,0),(36,'2017-06-30',9,1,0),(37,'2017-07-01',9,1,0),(38,'2017-07-02',9,1,0),(39,'2017-07-03',9,1,0),(40,'2017-07-04',9,1,0),(41,'2017-07-05',9,1,0),(42,'2017-07-06',9,1,0),(43,'2017-07-07',9,1,0),(44,'2017-07-08',9,1,0),(45,'2017-07-09',9,1,0),(46,'2017-07-10',9,1,0),(47,'2017-07-11',9,1,0),(49,'2017-07-12',9,1,0),(50,'2017-07-13',9,1,0),(51,'2017-07-14',9,1,0),(52,'2017-07-15',9,1,0),(53,'2017-07-16',9,1,0),(54,'2017-07-17',9,1,0),(55,'2017-07-18',9,1,0),(56,'2017-07-19',9,1,0),(57,'2017-07-20',9,1,0),(58,'2017-07-21',9,1,0),(59,'2017-07-22',9,1,0),(60,'2017-07-23',9,1,0),(61,'2017-07-24',9,1,0),(62,'2017-07-25',9,1,0),(63,'2017-07-26',9,1,0),(64,'2017-07-27',9,1,0),(65,'2017-07-28',9,1,0),(66,'2017-07-29',9,1,0),(67,'2017-07-30',9,1,0),(69,'2017-07-31',9,1,1),(70,'2017-08-01',9,1,1),(71,'2017-08-02',9,1,1),(72,'2017-08-03',9,1,1),(73,'2017-08-04',9,1,1),(74,'2017-08-05',9,1,1),(75,'2017-08-06',9,1,1),(76,'2017-08-07',9,1,1),(77,'2017-08-08',9,1,1),(78,'2017-08-09',9,1,1),(79,'2017-08-10',9,1,1),(80,'2017-08-11',9,1,1),(81,'2017-08-12',9,1,1),(82,'2017-08-13',9,1,1),(83,'2017-08-14',9,1,1),(84,'2017-08-15',9,1,1),(85,'2017-08-16',9,1,1),(86,'2017-08-17',9,1,1),(87,'2017-08-18',9,1,1),(88,'2017-08-19',0,1,1),(89,'2017-08-20',0,1,1),(90,'2017-06-26',9,3,0),(91,'2017-06-27',9,3,0),(92,'2017-06-28',9,3,0),(93,'2017-06-29',9,3,0),(94,'2017-06-30',9,3,0),(95,'2017-07-01',9,3,0),(96,'2017-07-02',9,3,0),(97,'2017-07-03',9,3,0),(98,'2017-07-04',9,3,0),(99,'2017-07-05',9,3,0),(100,'2017-07-06',9,3,0),(101,'2017-07-07',9,3,0),(102,'2017-07-08',0,3,0),(103,'2017-07-09',0,3,0),(104,'2017-07-10',9,3,1),(105,'2017-07-11',9,3,1),(106,'2017-07-12',9,3,1),(107,'2017-07-13',9,3,1),(108,'2017-07-14',9,3,1),(109,'2017-07-15',0,3,1),(110,'2017-07-16',0,3,1),(111,'2017-07-17',9,3,1),(112,'2017-07-18',9,3,1),(113,'2017-07-19',9,3,1),(114,'2017-07-20',9,3,1),(115,'2017-07-21',9,3,1),(116,'2017-07-22',0,3,1),(117,'2017-07-23',0,3,1),(118,'2017-07-24',9,3,1),(119,'2017-07-25',9,3,1),(120,'2017-07-26',9,3,1),(121,'2017-07-27',9,3,1),(122,'2017-07-28',9,3,1),(123,'2017-07-29',0,3,1),(124,'2017-07-30',0,3,1);
/*!40000 ALTER TABLE `actual_attendence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `monday` varchar(45) NOT NULL,
  `tuesday` varchar(45) DEFAULT NULL,
  `wednesday` varchar(45) DEFAULT NULL,
  `thursday` varchar(45) DEFAULT NULL,
  `friday` varchar(45) DEFAULT NULL,
  `saturday` varchar(45) DEFAULT NULL,
  `sunday` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`monday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES ('9','9','9','9','9','0','0');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(45) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`login_id`),
  KEY `fk_profile_id_idx` (`user_id`),
  CONSTRAINT `fk_profile_id` FOREIGN KEY (`user_id`) REFERENCES `profile` (`profile_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'emp2','corp@123',1,'s',2),(2,'admin','corp@123',2,'m',7),(3,'emp1','corp@123',3,'s',2),(4,'emp3','corp@123',4,'s',2);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `mail_id` varchar(45) DEFAULT NULL,
  `designation` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'sarthak',23,'sarthak@gmail.com','Software Engineer','1993-04-05'),(2,'Nitesh',35,'nitesg@gmail.com','Director','1947-04-05'),(3,'emp',22,'emp@gmail.com','Softwareengineer','1993-05-05'),(4,'mukerji',23,'muker@gmail.com','SoftEngineer','1993-04-02');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `current_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (2,'2');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-28 11:57:41
