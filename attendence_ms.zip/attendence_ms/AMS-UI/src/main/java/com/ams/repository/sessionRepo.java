package com.ams.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.ams.entity.Session;

public interface sessionRepo extends CrudRepository<Session, Serializable> {
	
	
	
	

}
