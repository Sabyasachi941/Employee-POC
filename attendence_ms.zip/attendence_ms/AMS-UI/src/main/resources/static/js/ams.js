function loginValidate(){
	
	var userName= document.getElementById("uname").value;
	var password=document.getElementById("upass").value;

	
	$.ajax({
	 url : "/loginValidate",
	 data: {
		 "userName" :userName,
		 "password" :password
	 },
	 type: "GET",
	 success : function(data){
		 
		 
		 
		 
		 if(data == "admin"){
			 window.location="/manager"
		 }else{
			 window.location=data+".html"
		 }

	 },
	 error:function(data){
		 alert("Please Enter a Valid user"+data)
	 }
	})
}



function getAttendence(){
	$("#EmpluseWeekly tr").remove();
	$.ajax({
	 url : "/getAttendence",
	 type: "GET",
	 success : function(data){
	
		
			var startDate=data[0].date
			startDate=startDate.split("-");
			
			
			var endDate=data[6].date
			endDate=endDate.split("-");
		 
		 var tr=[];
	  		tr.push('<tr style="color:#1e81d6;">');

	  			tr.push("<th><input type='button' value='previous'  style='margin:8%;' class='btn btn-primary ' onclick='previous("+startDate[0]+","+startDate[1]+","+startDate[2]+")' disabled/></th>");
	  			tr.push("<td> </td>");
	  			tr.push("<td> </td>");
	  			tr.push("<td> </td>");
	  			tr.push("<td> </td>");
	  			tr.push("<td> </td>");
	  			tr.push("<td> </td>");
	  				tr.push("<td><input type='button' value='next' style='margin:10%;'  class='btn btn-primary'  onclick='next("+endDate[0]+","+endDate[1]+","+endDate[2]+")' /></td>");

	  		
	  		
	  		tr.push('</tr>');
  		
  		
  		tr.push('<tr style="color:#1e81d6;">');
  		tr.push("<th>Monday</th>");
  		tr.push("<th>Tuesday</th>");
  		tr.push("<th>Wednesday</th>");
  		tr.push("<th>Thursday</th>");
  		tr.push("<th>Friday</th>");
  		tr.push("<th>Saturday</th>");
  		tr.push("<th>Sunday</th>");
  		tr.push("<th>Status</th>");
  		tr.push('</tr>');
  		
  		tr.push('<tr style="color:#1e81d6;">');
  		for(var i=0;i<data.length;i++){	
  			tr.push("<td>"+data[i].date+"</td>");
  		}
  		tr.push("<th>Manager Approval</th>");
  		tr.push('</tr>');
  		
  		
 		tr.push('<tr style="color:#1e81d6;">');
  		for(var i=0;i<data.length;i++){	
  			tr.push("<td>"+data[i].hours+"</td>");
  		}
  		if(data[1].status == 1){
  		tr.push("<th>Pending..</th>");
  		}else{
  			tr.push("<th>Approved</th>");
  		}
  		tr.push('</tr>');
  		
  		
  		
  		$('table[id=EmpluseWeekly]').append($(tr.join('')));
  		
    	  
		
		
		
	 },
	 error:function(data){
		 alert("error"+data)
	 }
	})
}

function previous(year,month,date){
	$("#EmpluseWeekly tr").remove();
	var startDate=year+"-"+month+"-"+date;
	
	
	$.ajax({
	 url : "/previous",
	 data: {
		 "startDate" :startDate
	 },
	 type: "GET",
	 success : function(data){
			var startDate=data[0].date
			startDate=startDate.split("-");
			
			
			var endDate=data[6].date
			endDate=endDate.split("-");
		 
		 var tr=[];
	  		tr.push('<tr style="color:#1e81d6;">');
	  		if(startDate[2] == 26 && startDate[1] == 06){
	  			tr.push("<th><input type='button' value='previous' style='margin:8%;' class='btn btn-primary' onclick='previous("+startDate[0]+","+startDate[1]+","+startDate[2]+")' disabled/></th>");
	  		}else{
	  			tr.push("<th><input type='button' value='previous'style='margin:8%;' class='btn btn-primary' onclick='previous("+startDate[0]+","+startDate[1]+","+startDate[2]+")' /></th>");
	  		}
	  		
	  		tr.push("<td> </td>");
  			tr.push("<td> </td>");
  			tr.push("<td> </td>");
  			tr.push("<td> </td>");
  			tr.push("<td> </td>");
  			tr.push("<td> </td>");
	  				tr.push("<th><input type='button' value='next'  style='margin:8%;' class='btn btn-primary' onclick='next("+endDate[0]+","+endDate[1]+","+endDate[2]+")' /></th>");

	  		
	  		
	  		tr.push('</tr>');
	  		
	  		
	  		tr.push('<tr style="color:#1e81d6;">');
	  		tr.push("<th>Monday</th>");
	  		tr.push("<th>Tuesday</th>");
	  		tr.push("<th>Wednesday</th>");
	  		tr.push("<th>Thursday</th>");
	  		tr.push("<th>Friday</th>");
	  		tr.push("<th>Saturday</th>");
	  		tr.push("<th>Sunday</th>");
	  		tr.push("<th>Status</th>");
	  		tr.push('</tr>');
	  		
	  		tr.push('<tr style="color:#1e81d6;">');
	  		for(var i=0;i<data.length;i++){	
	  			tr.push("<td>"+data[i].date+"</td>");
	  		}
	  		tr.push("<th>Manager Approval</th>");
	  		tr.push('</tr>');
	  		
	  		
	 		tr.push('<tr style="color:#1e81d6;">');
	  		for(var i=0;i<data.length;i++){	
	  			tr.push("<td>"+data[i].hours+"</td>");
	  		}
	  		if(data[1].status == 1){
	  	  		tr.push("<th>Pending..</th>");
	  	  		}else{
	  	  			tr.push("<th>Approved</th>");
	  	  		}
	  		tr.push('</tr>');
	  		
	  		
	  		
	  		$('table[id=EmpluseWeekly]').append($(tr.join('')));
	  		
	    	  
	
		
	 },
	 error:function(data){
		 alert("error"+data)
	 }
	})
}


function next(year,month,date){
	
	
	$("#EmpluseWeekly tr").remove();
	var startDate=year+"-"+month+"-"+date;
	
	
	$.ajax({
	 url : "/next",
	 data: {
		 "startDate" :startDate
	 },
	 type: "GET",
	 success : function(data){
		
			var startDate=data[0].date
			startDate=startDate.split("-");
			
			
			var endDate=data[6].date
			endDate=endDate.split("-");
		 
		 var tr=[];
	  		tr.push('<tr style="color:#1e81d6;" >');

	  			tr.push("<th><input type='button' value='previous' style='margin:8%;' class='btn btn-primary' onclick='previous("+startDate[0]+","+startDate[1]+","+startDate[2]+")' /></th>");

	  		/*	if(endDate[2] == 30 && endDate[1] == 07){
	  				tr.push("<th><input type='button' value='next' style='margin:8%;' class='btn btn-primary' onclick='next("+endDate[0]+","+endDate[1]+","+endDate[2]+")' disabled /></th>");
	  			}else{*/
	  				tr.push("<td> </td>");
		  			tr.push("<td> </td>");
		  			tr.push("<td> </td>");
		  			tr.push("<td> </td>");
		  			tr.push("<td> </td>");
		  			tr.push("<td> </td>");
	  				tr.push("<th><input type='button' value='next' style='margin:8%;' class='btn btn-primary' onclick='next("+endDate[0]+","+endDate[1]+","+endDate[2]+")'  /></th>");
	  			/*}*/
	  			
	  				

	  		
	  		
	  		tr.push('</tr>');
	  		
	  		
	  		tr.push('<tr style="color:#1e81d6;">');
	  		tr.push("<th>Monday</th>");
	  		tr.push("<th>Tuesday</th>");
	  		tr.push("<th>Wednesday</th>");
	  		tr.push("<th>Thursday</th>");
	  		tr.push("<th>Friday</th>");
	  		tr.push("<th>Saturday</th>");
	  		tr.push("<th>Sunday</th>");
	  		tr.push("<th>Status</th>");
	  		tr.push('</tr>');
	  		
	  		tr.push('<tr style="color:#1e81d6;">');
	  		for(var i=0;i<data.length;i++){	
	  			tr.push("<td>"+data[i].date+"</td>");
	  		}
	  		tr.push("<th>Manager Approval</th>");
	  		tr.push('</tr>');
	  		
	  		
	 		tr.push('<tr style="color:#1e81d6;">');
	  		for(var i=0;i<data.length;i++){	
	  			tr.push("<td>"+data[i].hours+"</td>");
	  		}
	  		if(data[1].status == 1){
	  	  		tr.push("<th>Pending..</th>");
	  	  		}else{
	  	  			tr.push("<th>Approved</th>");
	  	  		}
	  		tr.push('</tr>');
	  		
	  		
	  		
	  		$('table[id=EmpluseWeekly]').append($(tr.join('')));
	  		
	    	  
	
		
	 },
	 error:function(data){
		 alert("error"+data)
	 }
	})
	
	
}

function profileData(){
	$("#Empluse tr").remove();
	
	$.ajax({
		 type : "GET",
		 contentType : "application/json", 
		url : "/profile",
		dataType : 'json',
      success : function(data) {
    	
    	  
    	  
    	  
    	var tr=[];
  		tr.push('<tr style="color:#009688;">');
  		tr.push("<th>Name</th>");
  		tr.push("<td>"+data.userName+"</td>");
  		tr.push('</tr>');
  		
  		tr.push('<tr style="color:#009688;">');
  		tr.push("<th>Age</th>");
  		tr.push("<td>"+data.age+"</td>");
  		tr.push('</tr>');
  		
  		tr.push('<tr style="color:#009688;">');
  		tr.push("<th>Mail</th>");
  		tr.push("<td>"+data.mailId+"</td>");
  		tr.push('</tr>');
  		
  		tr.push('<tr style="color:#009688;">');
  		tr.push("<th>Designation</th>");
  		tr.push("<td>"+data.designation+"</td>");
  		tr.push('</tr>');
  		
  		tr.push('<tr style="color:#009688;">');
  		tr.push("<th>DoB</th>");
  		tr.push("<td>"+data.dob+"</td>");
  		tr.push('</tr>');
  		

  		$('table[id=Empluse]').append($(tr.join('')));
  		
    	  
      }
     	 
	});
	
}

function logout(){
	window.location="index.html";
}


function insertAttendance(){
	$("#manualAttendence tr").remove();
	$.ajax({
		 type : "GET",
		 contentType : "application/json", 
		url : "/ManualAttendence",
		dataType : 'json',
     success : function(data) {
   	
    	 
    	 
    	  
     	var tr=[];
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Monday</th>");
   		tr.push("<th><input  type='text'  id='date"+0+"'value='"+data[0].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='monday' name='monday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
 		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Tuesday</th>");
   		tr.push("<th><input  type='text'  id='date"+1+"'value='"+data[1].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='tuesday' name='tuesday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Wednesday</th>");
   		tr.push("<th><input  type='text'  id='date"+2+"'value='"+data[2].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='wednesday' name='wednesday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Thursday</th>");
   		tr.push("<th><input  type='text'  id='date"+3+"'value='"+data[3].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='thursday' name='thursday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Friday</th>");
   		tr.push("<th><input  type='text'  id='date"+4+"'value='"+data[4].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='friday' name='friday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Saturday</th>");
   		tr.push("<th><input  type='text'  id='date"+5+"'value='"+data[5].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='saturday' name='saturday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		tr.push('<tr style="color:#009688;">');
   		tr.push("<th>Sunday</th>");
   		tr.push("<th><input  type='text'  id='date"+6+"'value='"+data[6].date+"' disabled></th>")
   		tr.push("<td><input  type='text'  id='sunday' name='sunday' placeholder='Hours' value=''></td>");
   		tr.push('</tr>');
   		
   		
   		
   		
   		/*tr.push("<th>Tuesday</th>");
   		tr.push("<th>Wednesday</th>");
   		tr.push("<th>Thursday</th>");
   		tr.push("<th>Friday</th>");
   		tr.push("<th>Saturday</th>");
   		tr.push("<th>Sunday</th>");
   		tr.push('<td style="color:#009688;">');
   		
   		
   		for(var i=0;i<data.length;i++){
   			tr.push("<th><input  type='text'  id='date"+i+"'value='"+data[i].date+"' disabled></th>");
   			}
   		tr.push('</td>');
   		
   		tr.push('<tr style="color:#009688;">');
   		
   		tr.push("<td><input  type='text'  id='tuesday' name='tuesday' placeholder='Hours' ></td>");
   		tr.push("<td><input  type='text'  id='wednesday' name='wednesday' placeholder='Hours' ></td>");
   		tr.push("<td><input  type='text'  id='thursday' name='thursday' placeholder='Hours' ></td>");
   		tr.push("<td><input  type='text'  id='friday' name='friday' placeholder='Hours' ></td>");
   		tr.push("<td><input  type='text'  id='saturday' name='saturday' placeholder='Hours' value='0' disabled></td>");
   		tr.push("<td><input  type='text'  id='sunday' name='sunday' placeholder='Hours' value='0' disabled ></td>");
   		tr.push('</tr>'); */
 
  		
  		$('table[id=manualAttendence]').append($(tr.join('')));

}
	
	});
	
	}

/*function fileUpload(){
	
	var file=new FileReader();
	
	$.ajax({
		 type : "POST",
		 contentType : "MULTIPART_FORM_DATA", 
		url : "/fileUpload",
		dataType : 'file',
		data:{"file":file},
	 success : function(data) {
		 
		 
	 alert("Hi")
		 
	 }, error : function(data) {
		 alert("error")
	 }
		});
	
}*/


function insertManualAttendance(){

	
	var monday=document.getElementById("monday").value;
	var tuesday=document.getElementById("tuesday").value;
	var wednesday=document.getElementById("wednesday").value;
	var thursday=document.getElementById("thursday").value;
	var friday=document.getElementById("friday").value;
	var saturday=document.getElementById("saturday").value;
	var sunday=document.getElementById("sunday").value;
	$.ajax({
	 type : "GET",
	 contentType : "application/json", 
	url : "/ManualAttendence",
	dataType : 'json',
 success : function(data) {
	 
	

	 
	 
	 
	/*var DataJson = {"date0" :data[0].date, "date1":data[1], "date2":data[2],"date3" :data[3],"date4":data[4], "date5":data[5], "date6":data[6]};*/
	 var check0 = {"date" :data[0].date, "hours":monday};
	 var check1 = {"date" :data[1].date, "hours":tuesday};
	 var check2 = {"date" :data[2].date, "hours":wednesday};
	 var check3 = {"date" :data[3].date, "hours":thursday};
	 var check4 = {"date" :data[4].date, "hours":friday};
	 var check5 = {"date" :data[5].date, "hours":saturday};
	 var check6 = {"date" :data[6].date, "hours":sunday};
	 var DataJson=[];
		 DataJson.push(check0)
		 DataJson.push(check1)
		 DataJson.push(check2)
		 DataJson.push(check3)
		 DataJson.push(check4)
		 DataJson.push(check5)
		 DataJson.push(check6)
		       

	
		$.ajax({
	 type : "POST",
	 data : JSON.stringify(DataJson),
	 contentType : "application/json", 
	url : "/GetManualAttendence",
	dataType : 'json',
	
	 success : function(data) {
	 
	
	
	
 }, error : function(data) {
	 alert("error")
 }
	});
	
	
 }
	});
}