package com.ams.entity;

public class Profile {

}
