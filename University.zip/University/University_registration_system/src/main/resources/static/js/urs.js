function loginValidate(){

	var userName= document.getElementById("uname").value;
	var password=document.getElementById("upass").value;
		if (userName==null && password==null){
			alert("Enter Username and password")
		}
	//alert("password"+password)
	$.ajax({
		 url : "/loginValidate",
		 data: {
			 "userName" :userName,
			 "password" :password
		 },
		 type: "GET",
		 success : function(data){
			 
			 if(data == "admin"){
				 window.location="admin.html"
			
			 }else if(data == "student"){
				 window.location="student.html"
			 }
			 else{
				 alert("Please Enter a Valid UserID and Password")
			 }
		 },
//		 error:function(data){
//			 alert("Please Enter a Valid user"+data)
//		 }
		})
	}

function register() {
	var fName = document.getElementById("fName").value;
	var lName = document.getElementById("lName").value;
	var marks = document.getElementById("marks").value;
	var nationality = document.getElementById("nationality").value;
	var state = document.getElementById("state").value;
	
	//var elements =  document.getElementById("insertForm").elements;
	var DataJson=[];
	 DataJson.push(fName)
	 DataJson.push(lName)
	 DataJson.push(marks)
	 DataJson.push(nationality)
	 DataJson.push(state)
	
	$.ajax({
		 type : "POST",
		 data : JSON.stringify(DataJson),
		 contentType : "application/json", 
		url : "/insertData",
		dataType : 'json',
			 
		success : function(data) {
			 
			
			
			
		 },
}