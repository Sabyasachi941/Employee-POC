package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stusent")
public class Student {

	@Id
	@Column(name="fname")
	private String fName;
	
	@Column(name="lname")
	private String lname;
	
	@Column(name="marks")
	private int marks;
	
	@Column(name="nationality")
	private String nationality;
	
	@Column(name="state")
	private String state;

	public Student() {
		super();
	}

	

	public Student(String fName, String lname, int marks, String nationality, String state) {
		super();
		this.fName = fName;
		this.lname = lname;
		this.marks = marks;
		this.nationality = nationality;
		this.state = state;
	}



	public String getfName() {
		return fName;
	}



	public void setfName(String fName) {
		this.fName = fName;
	}



	public String getLname() {
		return lname;
	}



	public void setLname(String lname) {
		this.lname = lname;
	}



	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	
	
	
}
