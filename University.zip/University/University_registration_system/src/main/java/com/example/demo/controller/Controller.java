package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ams.entity.check;
import com.example.demo.entity.Login;
import com.example.demo.entity.Student;
import com.example.demo.services.UrsService;



@RestController
public class Controller {
	
	@Autowired
	private UrsService service;
	
	@RequestMapping(value="loginValidate", method=RequestMethod.GET,produces=MediaType.TEXT_HTML_VALUE)
	public String validateUser(@RequestParam("userName") String UserName, @RequestParam("password") String password){
		Login userDetail = service.getUser(UserName,password);
		
		//System.out.println("password paste in html is"+password);
		String databasePassword =userDetail.getPassword();
		String givenPassword = password;
		if(databasePassword.equals(givenPassword))
		{	
			//System.out.println("database password is"+databasePassword);
			if(userDetail.getRole().equals("admin")){
//				System.out.println("password is"+userDetail.getRole());
				return "admin";
				}
			else {
				return "student";
				}
		}
		else{
			return "error";
		}
		
	}
	@RequestMapping(value="insertData", method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public String InsertUser(@RequestBody Student DataJson){
		
		String fullName = DataJson.

		
		return password;
	
	
		
	}
}
	

