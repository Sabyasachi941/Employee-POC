package com.example.demo.services;

import com.example.demo.entity.Login;

public interface UrsService {
	

	public Login getUser(String userName, String password);

}
