package com.example.demo.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Login;

@Repository
public interface LoginRepo extends CrudRepository<Login, Serializable> {
	
	public Login findByuserName(String userName); 
}
