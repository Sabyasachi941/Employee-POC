package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Login;
import com.example.demo.repository.LoginRepo;

@Service
public class UrsServiceImpl implements UrsService {

	@Autowired
	private LoginRepo loginRepo;
	
//	private Login login;
	
	@Override
	public Login getUser(String userName, String password) {
		return loginRepo.findByuserName(userName);
		
	}

}
